# BLACKLIGHT · SIGNAL & SOUL

### Lit 3 · TypeScript · Atomic Design · v2.0 beta

A reusable, framework-agnostic UI library implementing the Blacklight visual language in standard **Web Components**, authored in **TypeScript** and backed by **Lit**. Includes 52 custom elements, semantic theme tokens, an interactive catalog, four application pages, research decisions, and browser tests.

> **Status:** beta / implementation preview. Not yet published or certified accessible. See [quality assurance](docs/QA.md) for test commands and coverage boundaries.

## Quick start

Requirements: Node 20.19+ and pnpm. The repository includes a pnpm lockfile.

```bash
git clone https://github.com/BlackNexys/Blacklight-UI.git
cd Blacklight-UI
pnpm install --frozen-lockfile
pnpm run dev            # Vite demo at http://127.0.0.1:4173
pnpm run typecheck
pnpm run build:demo     # Build the standalone demo into demo-dist/
pnpm run build          # TypeScript -> dist ESM, .d.ts, .map; copies CSS and fonts
pnpm exec playwright install chromium
pnpm test               # Playwright: desktop + mobile
pnpm run test:source
npm pack --dry-run      # inspect publication contents
```

If Playwright browsers are already present, skip the installation step. On Windows with Microsoft Edge installed, set `PLAYWRIGHT_CHANNEL=msedge` to use Edge instead. `pnpm test` is the Playwright test suite. This project has not been published to a registry; choose a license and verify scope ownership before publishing.

## Optional application tools

Compose responsive pages with `bl-stack`, `bl-inline`, `bl-grid` and `bl-container`, also available from `@blacklight/signal-soul/layout`. See [layout primitives and CMS composition](docs/LAYOUT.md) and the demo at `/layouts`.

Build app workflows with the optional `/router`, `/events`, `/lifecycle`, and `/application` entries. They provide routing, typed DOM events, cleanup, scoped context, form workflows, async state, validated preferences, and reusable actions. Lit adapters are separate `/lit` entries. These tools add no dependencies and start no global listeners on import. See [Application tools](docs/APPLICATION_TOOLS.md) for examples and lifecycle contracts.

## Install in another local project

Create an installable archive from this checkout:

```bash
npm run pack:local
```

The `prepack` hook builds the current sources automatically, including TypeScript declarations,
theme CSS, fonts, and icons. This creates `blacklight-signal-soul-2.0.0-beta.1.tgz` in the project
root. It does not publish anything to npm, and no npm account is needed.

From the project that will use Blacklight, install that archive and its Lit peer dependency.
For this checkout on Windows:

```powershell
npm install "C:/Users/almn/Desktop/Blacklight_Lit_UI_v2/blacklight-signal-soul-2.0.0-beta.1.tgz" lit
```

You can also copy the archive into the other project, for example under `vendor/`, and run:

```bash
npm install ./vendor/blacklight-signal-soul-2.0.0-beta.1.tgz lit
```

Keep that archive available at the recorded path for future installs. The archive contains a
snapshot of the library. After making library changes, run `npm run pack:local` again and reinstall
the new archive in the consuming project. For distinct releases, bump the version first with
`npm version prerelease --preid=beta --no-git-tag-version` and use the new archive filename.

For a live local link instead, build this checkout with `npm run build`, then run
`npm install /absolute/path/to/Blacklight_Lit_UI_v2 lit` in the consuming project. Rebuild the
library after changes; linked dependencies may also require bundler configuration.

Import registrations and the complete theme in your application's browser entry point
(with a bundler such as Vite):

```ts
import '@blacklight/signal-soul';
import '@blacklight/signal-soul/theme.css'; // tokens, self-hosted fonts and document typography

// Native Web Components work in plain HTML, Vue, Svelte, Angular, etc.
```

The theme applies Signal to document headings and Voice Sans to body text and native controls. Lit components use the same font-role tokens inside their shadow roots. All demo entry points use this shared theme. For separate styling, import `tokens.css`, `fonts.css`, and `typography.css` individually; `fonts.css` only registers the faces and font stacks. Override `--bl-font-display`, `--bl-font-body`, or `--bl-font-editorial` after the theme to supply application fonts.

### Programmatic interactions

```ts
import { createUIService } from '@blacklight/signal-soul/services';

const ui = createUIService({ root: document.querySelector('#app')! });
ui.toast({ title: 'Record updated', tone: 'success' });
const result = await ui.confirm({ heading: 'Continue?', message: 'Review the record first.' });
// Call ui.dispose() when the application is torn down.
```

The service also opens drawers, queues its modal requests, and defers its notifications while a modal is active. See [UI services](docs/UI_SERVICES.md) for options, return values, and cleanup.

For localized text in application code and markup, the dependency-free [translation service](docs/TRANSLATION.md) accepts JSON dictionaries. Attach it to a root to use `<bl-translation key="…">` in markup. Pass translated text to other components through their properties, slots, or messages.

```html
<bl-button variant="primary" id="confirm">Review record</bl-button>
<bl-badge tone="warning">Provisional</bl-badge>
<bl-input name="person" label="Person name" required></bl-input>

<script type="module">
  const button = document.querySelector('#confirm');
  button.addEventListener('click', () => console.log('Review requested'));
</script>
```

The `bl-button` has a native `<button>` inside shadow DOM. Its public API: `variant` = primary / secondary / outline / quiet / human / danger; `size` = sm / md / lg; boolean `full`, `disabled`, `loading`, `icon-only`; `type` = button / submit / reset. For icon-only use `<bl-button icon-only aria-label="Add record">+</bl-button>`.

Forms use ElementInternals:

```html
<form id="request">
  <bl-input name="contact" label="Contact name" required></bl-input>
  <bl-checkbox name="consent" required>I understand the terms</bl-checkbox>
  <bl-button type="submit" variant="primary">Request review</bl-button>
</form>
```

```ts
const form = document.querySelector<HTMLFormElement>('#request')!;
form.addEventListener('submit', (event) => {
  event.preventDefault();
  const formData = new FormData(form); // includes registered controls
  console.log(Object.fromEntries(formData));
});
```

`bl-file-input` submits native files under its `name`, with optional multiple selection, browse/drop constraints and structured rejection feedback. See [file input and media workflows](docs/MEDIA_UI.md) for its form contract and the upload/media-picker examples.

Properties that accept arrays are supplied programmatically (not serialized JSON in HTML attributes):

```ts
import type { BlDataTable, BlSelect } from '@blacklight/signal-soul';
const select = document.querySelector<BlSelect>('bl-select')!;
select.options = [
  { label: 'Provisional', value: 'provisional' },
  { label: 'Verified', value: 'verified' },
];
const table = document.querySelector<BlDataTable>('bl-data-table')!;
table.columns = [
  { key: 'subject', label: 'Subject', sortable: true },
  { key: 'status', label: 'Status' },
];
table.rows = [{ subject: 'Continuity review', status: 'Provisional' }];
```

## VS Code themes

The same design tokens also generate **Blacklight · Signal & Soul Dark** and **Light** editor
themes, plus a matching file and folder icon theme. With Node 22+, build an installable VSIX from this checkout:

```bash
npm ci --prefix vscode-theme
npm run theme:pack
code --install-extension ./vscode-theme/blacklight-signal-soul-0.2.0.vsix
```

Select a variant with **Preferences: Color Theme**, then choose **Blacklight · Signal & Soul Icons**
with **Preferences: File Icon Theme**. See the [theme documentation](vscode-theme/README.md)
for palette mapping, maintenance, and checks. The extension is packaged separately from the UI library.
The [release guide](vscode-theme/RELEASING.md) covers publishing the themes and icons together to the
VS Code Marketplace; `npm run theme:release:check` verifies release metadata before publishing.

## Packages and architecture

```
Blacklight_Lit_UI_v2/
  src/
    atoms/         18 components
    icons/         generated SVG templates, typed registry and metadata
    molecules/     15 components
    organisms/     11 components
    styles/        tokens.css, fonts.css, scoped shared styles
    index.ts       registration + class exports
  design-tokens.json
  glyphs/           editable SVG sources, manifest, and provenance
  demo/             TypeScript + Vite interactive library and application pages
  docs/             research register, architecture, migration and QA
  tests/            Playwright interaction and layout tests
  scripts/          build copies, source tests
  dist/             generated ESM + .d.ts (created by the build; not tracked in Git)
```

### Rich text authoring

`bl-rich-text` is a dependency-free Lit adaptation of the earlier AMNUI editor, with H1–H6, preformatted blocks, lists, safe links, filtered paste, per-editor undo/redo, and native form participation. Configure commands with `actions` and retained document markup with `allowed-elements`; the default vocabulary includes code, tables, figures and definition lists. Open `/rich-text.html` for the form/reading-preview demo, or `/library/bl-rich-text` for full and constrained examples. See [the editor contract and browser boundary](docs/RICH_TEXT_EDITOR.md).

### Atomic design approach

Blacklight Glyphs supplies 54 original icons and a `bl-icon` atom: the v0.3 catalogue's 48 core concepts plus six existing UI helpers. Icons inherit UI text color through `currentColor`; provide `label` for standalone informative icons and label the button for icon-only actions. View `/library/icons` for searchable families, catalogue IDs, size previews, meaning boundaries, and live composition examples, or `/glyphs.html` for the twelve-icon construction atlas. Use `@blacklight/signal-soul/icons` for typed templates/metadata, or `/icons/svg/search.svg` for individual SVG assets. See [glyph documentation](glyphs/README.md).

The [Signal vector study](docs/SIGNAL_VECTOR_STUDY.md) supplies the default display face: sharp capitals, distinct lowercase, Latin-1 accents, figures, and punctuation constructed as clean SVG outlines. Open `/signal-proof.html` in the demo to compare it with its traced predecessor.

The [Voice Sans vector study](docs/VOICE_VECTOR_STUDY.md) supplies the default reading face, with smooth curves, uppercase/lowercase, Nordic letters, and proofs at interface sizes. Open `/voice-proof.html` for the comparison and a Lit component context.

Atoms own accessible control semantics and visual language. Molecules combine atoms or native browser patterns. Organisms compose whole content areas. Complete page templates live in the demo, not the runtime package. This is a **composition model**, not an assertion that every reusable piece needs a custom tag.

The demo is organized as a Lit application with page-owned state, explicit route lifecycle, and per-component catalogue entries. See [architecture](docs/ARCHITECTURE.md#demo-application-ownership) before extending it. `pnpm build:demo` builds the app and standalone reference pages into `demo-dist/`; `pnpm preview` serves that output.

The `/editor` route demonstrates [structured editing](docs/STRUCTURED_EDITING.md): repeatable links, localized content, nested validation, save failures, autosave and explicit draft recovery.

The `/revisions` route demonstrates [revision comparison and restore](docs/REVISIONS.md): escaped structured differences, append-only restoration, three-way conflict decisions and version-checked writes using the editor's simulated adapter.

`bl-combobox multiple` provides [multi-value relationships](docs/MULTI_SELECTION.md) with built-in removable chips, ordered repeated form values and labels retained across remote result pages. See `/library/bl-combobox` for the reusable mode and earlier application-owned composition.

The `/collections` route demonstrates [collection workflows](docs/COLLECTIONS.md): controlled table multiple selection, filter/sort views, explicit cross-page scope and simulated bulk actions with partial failure recovery.

The `/scheduling` route demonstrates [native date/time inputs and scheduling](docs/SCHEDULING.md): explicit timezones, skipped/repeated local times, exact-instant confirmation and simulated schedule saving.

The [custom date picker](docs/DATE_PICKER.md), `bl-date-picker`, follows Blacklight's field and calendar styling, with typed ISO dates, keyboard month/year navigation and native form association. Try `/library/bl-date-picker` or the default date fields in `/scheduling`.

For a combined calendar and clock, use `bl-date-picker type="datetime-local"`. For a standalone clock, use `bl-time-picker`. Both provide custom hour/minute editing with explicit Apply/Cancel; see [time and combined pickers](docs/TIME_PICKER.md) and `/library/bl-time-picker`.

### Styling

- Void `#08090D`, Blackglass `#0E1017`, Carbon `#141722`, fields `#1C202D`, active surfaces `#252A3A`; neutral white/gray layers in light mode.
- Blacklight indigo `#5900FF`, readable Signal `#BCA8FF`.
- Human ember `#EAC080`, Dreamscape Ghost `#79D6D1`.
- Fonts: bundled Blacklight Signal Vector Study (Regular 400) for headings and component titles, including table headers; Blacklight Voice Sans Vector Study for copy and controls; and optional Blacklight Voice Serif Atlas for editorial passages. The corresponding Atlas faces follow each new face in the font stacks to cover unsupported characters. Signal covers 206 character mappings, including distinct lowercase and Latin-1; Voice Sans covers 111. Each family supplies a regular face; browsers synthesize bold or italic styles where needed. Import `fonts.css` to load the self-hosted WOFF2 assets, or define your own `--bl-font-display`, `--bl-font-body`, and `--bl-font-editorial`. Sources remain in `src/fonts`; builds copy the web fonts and Noto OFL attribution into `dist/fonts`.
- `data-theme="light"` on `<html>` switches semantic token aliases where applicable.

### Known limitations

- **Not yet published**; npm scope needs ownership and license decision (package is currently `UNLICENSED`).
- Firefox/Safari, physical devices, screen-reader speech, forced colors, RTL, and every property/variant combination remain unverified. The two misleading tests recorded by the initial audit have been corrected.
- Mobile/accessibility audits are not complete. Automated tests provide coverage, not certification.
- The package exposes basic form-associated controls, but native submitter details (e.g. button `name=value` inside `FormData`) are not fully emulated.
- `bl-data-table` is not an enterprise virtualized data grid; intended for moderate client-side lists.

## Documentation

Start with the [documentation index](docs/README.md) for usage, contributing, design foundations, and historical reviews. The most-used guides are:

- [Component reference](docs/COMPONENTS.md) and [UI services](docs/UI_SERVICES.md)
- [Architecture](docs/ARCHITECTURE.md), [coding guidance](AGENTS.md), and [quality assurance](docs/QA.md)
- [Visual direction](docs/BLACKLIGHT_VISUAL_DIRECTION.md), [glyphs](glyphs/README.md), and [fonts](src/fonts/README.md)

The philosophy remains unchanged: **the system should serve the people, not define them.**
