# Programmatic UI services

`createUIService` creates an optional, application-scoped service using the existing Blacklight components. It adds no runtime dependency beyond the library's Lit peer dependency. Import it from the package root or `@blacklight/signal-soul/services`.

```ts
import { createUIService } from '@blacklight/signal-soul/services';

const ui = createUIService({ root: document.querySelector('#app')! });

ui.toast({ title: 'Record updated', message: 'Source retained.', tone: 'success' });

const result = await ui.confirm({
  heading: 'Remove this record?',
  message: 'This action cannot be undone.',
  confirmLabel: 'Remove',
  tone: 'danger',
});
if (result === 'confirm') await removeRecord();

// When the application is torn down:
ui.dispose();
```

The default root is `document.body`. A supplied root must be a connected `HTMLElement` or `ShadowRoot`; service elements inherit its theme and direction. The application owns the service and must call `dispose()` when that root is torn down. Calls after disposal or while its root is disconnected throw. Do not place the root inside content made inert by a separate modal.

## Toasts

`toast({ title, message?, tone?, duration? })` returns a handle with `await dismiss()`. Duration is milliseconds; `0` keeps a toast until dismissal. If omitted, danger notifications persist and other tones use the component's default duration. Configure the shared region with `toastPosition: 'top-start' | 'top-end' | 'bottom-start' | 'bottom-end'`; the default is `bottom-end`.

Toasts requested while this service has an open or queued modal wait until its modal queue is empty. Existing service toast timers pause while its modal is active. A queued toast can be dismissed before it appears. This coordination is per service; use one service for interactions that must share a queue, and coordinate separately with modals opened outside it.

## Confirmations

`confirm` requires `heading` and `message`, and accepts `confirmLabel`, `cancelLabel` and `tone: 'primary' | 'danger'`. Its promise resolves after the native dialog closes and its exit completes:

- `confirm`: the confirm action was selected.
- `cancel`: the cancel action was selected.
- `dismiss`: Escape or the close button dismissed the dialog.
- `dispose`: the service was disposed before completion.

Confirmations and service drawers run one at a time in request order. Dialog text is inserted as text, not parsed as HTML. The native dialog handles modal focus and background inertness.

## Drawers

```ts
const nav = document.createElement('bl-nav');
nav.label = 'Primary';
nav.items = [{ label: 'Records', href: '/records' }];

const drawer = ui.openDrawer({ heading: 'Navigation', side: 'start', content: nav });
nav.addEventListener('click', (event) => {
  if (event.composedPath().some((node) => node instanceof HTMLAnchorElement)) void drawer.close();
});
const result = await drawer.closed; // 'close', 'dismiss', or 'dispose'
```

`content` accepts a text string, a DOM node, or a function returning a node. Strings are rendered as text; passed nodes are moved into the drawer and removed with it. The factory is called only when the drawer reaches the front of the queue. `side` defaults to `end` and follows writing direction. `close()` can also cancel a drawer that has not opened yet; it resolves after closure. Use CSS variables on the root to configure dimensions, such as `--bl-drawer-width`.

Disposal removes the service's region and modal, clears pending notifications, and resolves outstanding modal requests with `dispose`. Repeated disposal is safe. Opening errors, including errors thrown by a content factory, reject the affected promise and allow the queue to continue.

Service-created dialogs, drawers, and toast regions accept caller-provided internal labels through the `messages` option on `createUIService`. This is a snapshot; the UI service does not subscribe to translation context. Use `confirmLabel` and `cancelLabel` on confirmation requests. See [translation](TRANSLATION.md) for message keys and explicit application bindings.
