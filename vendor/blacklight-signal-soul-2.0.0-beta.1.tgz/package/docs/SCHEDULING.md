# Native dates and scheduling

## Control contract

`BlInputType` includes `date`, `time` and `datetime-local`. These use the existing native input, labels, input/change events, constraints, form association, reset and restoration. Values remain normalized strings: a calendar date (`YYYY-MM-DD`), a time (`HH:mm`, with optional seconds when enabled), or a local date/time (`YYYY-MM-DDTHH:mm`, optionally with seconds). None contains a timezone. Empty or syntactically invalid values follow native sanitization. `min`/`max` use the type's string syntax; `step` is days for dates and seconds for time/local date-time. Native pickers and segment order belong to the browser and operating system; no calendar popup or calendar keyboard model is added.

The [HTML input standard](<https://html.spec.whatwg.org/multipage/input.html#date-state-(type=date)>) defines these value and constraint semantics. The library does not turn a calendar date into a JavaScript Date, infer a timezone, or schedule a server job.

The input value binding compares against the current native value before writing. This preserves partially edited native date/time segments during reactive updates, while the form value remains the normalized string (empty until the browser has a complete syntactically valid value). Set CSS `color-scheme` on your themed application root so native picker controls follow the chosen theme; the demo does this for dark and light modes.

## Scheduling composition

The default entry mode uses the [combined custom date/time picker](TIME_PICKER.md). Separate mode uses the [custom date picker](DATE_PICKER.md) and standalone time picker. Both modes feed the same application-owned timezone resolver. Native `bl-input` date/time types remain available in the component reference.

The `/scheduling` demo owns the editorial date, publication wall time, scheduling timezone, repeated-time choice, resolved instant and display timezone. An editorial date is a date-only label and stays unchanged across timezones. Publication can be entered as a combined local date/time or separate date and time controls. Both modes share the same fields and minute precision.

The application resolves a local time in an explicitly chosen IANA timezone before confirmation. A skipped daylight-saving time is rejected; a repeated time requires selecting an occurrence identified by offset and UTC instant. The confirmation includes the local value, scheduling timezone and exact UTC instant. Changing the display timezone changes only formatted previews and saved-result labels. Changing the scheduling timezone retains the wall time and requires resolution again.

This is a bounded demonstration: Gregorian dates in 2026–2028, minute precision, and UTC, Europe/Copenhagen, America/New_York and Asia/Kolkata. Its resolver samples nearby offsets with [Intl.DateTimeFormat](https://tc39.es/ecma402/#sec-intl.datetimeformat.prototype.formattoparts) and round-trips candidates against the requested wall time. It depends on the runtime timezone database and rejects unavailable zones. It is demo code, not a general timezone library or a public scheduling service. Production applications should use their server's authoritative timezone resolver and explicitly decide their ambiguity policy.

The fixed demo clock is `2026-10-29T12:00:00Z`; past instants are rejected relative to that clock. A cancellable local adapter simulates saving a schedule, including failure and retry. It performs no real publication or remote writes. Committed schedules and unfinished inputs live in the cached page until reload. Route teardown aborts local work. Confirmation is not server authorization; real services must recheck permissions, clock, timezone data and scheduling rules, and reconcile outcomes after cancellation.

Internal application links ask before leaving an active save. Browser history and direct programmatic navigation bypass that link guard, but disconnection still cancels the task. A connection revision invalidates outstanding confirmations so an old answer cannot start a save after reconnection. A shared-shell dialog already open during history navigation may remain until dismissed; its old answer is ignored. No browser-unload or remote rollback guarantee is provided.

## Verification

Check native type/value normalization, constraints, FormData, reset, restore, inherited disabled state and readonly behavior. Exercise normal times, gaps, repeated times, half-hour offsets, host timezone independence, mode switching, explicit confirmation, display-only timezone changes, save failure, cancellation and route reconnection. Review keyboard focus, both themes, narrow RTL layouts, forced colors and large text. Native picker appearance and physical-device behavior need browser/OS review; NVDA/Firefox and VoiceOver/Safari checks remain manual.

Verified on 29 October 2026 using installed Edge with desktop and mobile-emulation Playwright profiles: all 26 date/time and scheduling checks passed, including segment editing compared with plain native controls and stale confirmations across reconnection. The 74 existing component refinement/usage, form regression, navigation and structured-editing checks also passed. Type checking, ESLint, library/demo builds, source guards and package dry-run passed. Desktop dark and narrow RTL light layouts were visually reviewed. Changed files pass formatting; the full formatting check still reports existing issues in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`. Manual assistive-technology and physical-device picker review remains pending.
