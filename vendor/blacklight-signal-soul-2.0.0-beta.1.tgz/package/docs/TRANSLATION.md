# Translation

The translation service accepts ordinary JSON-shaped dictionaries and works in application code without a DOM or additional dependencies. The optional `<bl-translation>` component renders the same keys in markup. Import the service from `@blacklight/signal-soul/translation`; import `@blacklight/signal-soul` or `@blacklight/signal-soul/atoms` to register the component.

```json
{
  "records": {
    "saved": "Record {id} was saved.",
    "count": { "one": "{count} record", "other": "{count} records" }
  }
}
```

```ts
import { createTranslationService } from '@blacklight/signal-soul/translation';
import en from './en.json';
import da from './da.json';

const i18n = createTranslationService({
  locale: 'en',
  fallbackLocale: 'en',
  translations: { en, da },
});
i18n.t('records.saved', { id: 'BL-102' });
i18n.t('records.count', { count: 2 });
const unsubscribe = i18n.subscribe((locale) => console.log(locale));
i18n.setLocale('da');
unsubscribe();
```

Keys use dots to address nested dictionary entries. Values are strings or plural-category objects. Plurals use `Intl.PluralRules` for the locale that supplied the message; provide an `other` form, plus the categories your language needs. Placeholder values are inserted as text. Missing parameters remain visible as `{name}`. The service does not parse translated strings as HTML.

Lookup tries the exact locale and progressively less-specific locale tags, then the configured fallback in the same way, and finally Blacklight's built-in English messages. Built-in component messages are available in English and Danish; an application dictionary for the same locale overrides them. Missing keys return the key and call `onMissing(key, locale)` when supplied; otherwise a warning is written to the console. `setTranslations(locale, dictionary)` replaces that locale's application dictionary and notifies subscribers. Treat dictionaries as immutable between calls. Locale tags are validated with `Intl`; invalid tags throw.

Use `formatNumber(value, options?)` and `formatDate(value, options?)` for locale-aware formatting. Applications choose their own date/time zone, locale loading, and storage. Set `lang` and `dir` explicitly where needed; the service does not change them automatically.

## Component context

```html
<main id="app">
  <h1><bl-translation key="records.heading"></bl-translation></h1>
  <bl-translation id="record-count" key="records.count"></bl-translation>
</main>
```

```ts
const detach = i18n.attach(document.querySelector('#app')!);
document.querySelector('bl-translation#record-count')!.values = { count: 2 };
// On application teardown:
detach();
```

The nearest attached root supplies a service, including across shadow roots; nested roots can use a different service. Attachments can be made before or after components connect. Attaching or detaching rebinds existing descendants, and connected components unsubscribe when removed. One service may attach to multiple roots; each root accepts one service at a time. The returned detach function is idempotent. Assign a new `values` object when parameters change so Lit observes the update. A missing key is displayed as its key; an empty `key` renders nothing.

## Supplying translated text to components

General UI components do not look up keys or subscribe to translation context. Their text properties and slots render the values supplied by the application; otherwise they use English defaults. Bind the service in application code when those values need to follow the locale:

```ts
const search = document.querySelector('bl-search')!;
const update = () => {
  search.label = i18n.t('blacklight.search.label');
  search.buttonText = i18n.t('blacklight.search.button');
};
const unsubscribe = i18n.subscribe(update);
update();
// On application teardown: unsubscribe();
```

For internal text that cannot be supplied through a property or slot, components expose a property-only `messages` object. Its keys identify component text, and its values are finished strings, not translation keys. Assign a new object to update a component; omitted keys use the English default. Placeholder markers such as `{page}` are filled from the component's current state.

```ts
const pagination = document.querySelector('bl-pagination')!;
const updatePagination = () => {
  pagination.messages = Object.fromEntries(
    ['label', 'previous', 'next', 'summary'].map((name) => {
      const key = `blacklight.pagination.${name}`;
      return [key, i18n.t(key)];
    }),
  );
};
const stopPagination = i18n.subscribe(updatePagination);
updatePagination();
```

The supported keys and placeholders are listed with their English defaults in [component-text.ts](../src/styles/component-text.ts). English and Danish dictionaries are provided as a convenience by the translation service, and applications can override them. Other languages can supply their own dictionaries. A component's regular properties, such as `label`, `heading`, and `placeholder`, and its named slots remain the appropriate way to supply that content; `messages` covers its internal text.

For UI-service-created dialogs, drawers and toast regions, pass `messages` to `createUIService`. This is a snapshot for the lifetime of the service. Supply confirmation button text using `confirmLabel` and `cancelLabel` in each request. As with any caller-provided content, the service does not observe translation context or update these values automatically.

The demo's Translation component reference shows explicit bindings for markup and component properties. Application-authored copy and consumer content are the application's responsibility.

Media players use a focused `MediaMessages` object with keys such as `play`, `pause`, `seek`, and `volume`. Bind translated strings explicitly just as for other component properties. See [media configuration](COMPONENT_CONFIGURATION.md#media) for the control and slot contract.
