# Layout primitives

Import `@blacklight/signal-soul/layout` to register `bl-stack`, `bl-inline`, `bl-grid` and `bl-container`. The main package entry also registers them. They inherit typography, add no roles or keyboard behavior, and preserve content and focus order. The demo at `/layouts` combines them and renders a small CMS-style document.

```html
<bl-container size="lg" gutter="4">
  <bl-stack gap="6">
    <h1>Records to review</h1>
    <p>Read the source before deciding.</p>
    <bl-grid gap="4" min-item-width="sm">
      <bl-card>Arrival interview</bl-card>
      <bl-card>Independent account</bl-card>
      <bl-card>Review notes</bl-card>
    </bl-grid>
    <bl-inline gap="3" justify="end">
      <bl-button variant="quiet">Save draft</bl-button>
      <bl-button variant="primary">Continue</bl-button>
    </bl-inline>
  </bl-stack>
</bl-container>
```

## Settings

| Component      | Properties and defaults                                                                                               |
| -------------- | --------------------------------------------------------------------------------------------------------------------- |
| `bl-stack`     | `gap=4`, `align="stretch"`                                                                                            |
| `bl-inline`    | `gap=3`, optional `rowGap` / `columnGap`, `align="center"`, `justify="start"`, `wrap="wrap"`                          |
| `bl-grid`      | `gap=4`, optional `rowGap` / `columnGap`, `align="stretch"`, `columns="auto"`, `minItemWidth="md"` (`min-item-width`) |
| `bl-container` | `size="lg"`, `gutter=4`                                                                                               |

`gap` and `gutter` accept token steps **0, 1, 2, 3, 4, 5, 6, 8, 10, 12, 16, 20, 24**. Each whole step corresponds to 0.25rem; `gap="6"` uses `--bl-space-6` with a 1.5rem fallback. Missing or unsupported values use the component default. These numbers are token steps, not pixels.

`align` accepts `start`, `center`, `end`, `stretch` and `baseline`. Baseline alignment is useful for inline headings, links and controls with different text sizes. For stack it controls horizontal alignment; for inline it controls alignment within a row; for grid it controls alignment within each grid cell. `justify` accepts `start`, `center`, `end` and `between`. Logical start/end follow writing direction. Layout alignment preserves inherited text alignment; set `text-align` in application CSS when text itself should align differently. No reverse/order API is provided, so visual and reading order stay together.

Automatic grid columns use `auto-fit` with equal flexible tracks. `min-item-width="sm|md|lg"` selects a preferred minimum of 12rem, 16rem or 20rem, bounded to the available width. A single item can therefore fit in a container narrower than that preference. Hidden children do not retain a cell. `columns="1"` through `columns="12"` select a fixed count that stays fixed at narrow widths; choose automatic columns when reflow is desired. In JavaScript, set `.columns = 2` or `.columns = 'auto'`.

Inline and grid also accept `row-gap` / `.rowGap` and `column-gap` / `.columnGap`. Omitted or invalid values fall back to the shared gap. This keeps wrapped rows close together while separating actions more generously, for example `row-gap="2" column-gap="6"`. Dedicated axis CSS overrides take precedence, followed by the explicit axis property, then the shared gap CSS override and `gap` property.

`columns="1-2-3"` uses one column below 30rem of available container width, two from 30rem and three from 50rem. `columns="1-2-4"` uses one below 30rem, two from 30rem and four from 60rem. `columns="2-4"` keeps two columns below 60rem and four from 60rem, suitable for compact swatches. These presets query an internal width container and do not depend on viewport width. Thresholds scale with the root font size. `min-item-width` applies only to `columns="auto"`; fixed counts and responsive presets define their own tracks. Automatic and fixed modes retain their existing behavior.

For rows mixing labelled fields and actions, use `align="end"` so the input/select edges align with the buttons. Use `align="baseline"` for headings and related text, and the default centered alignment for button-only groups.

For filter bars, put `data-bl-grow` on the direct child of an inline layout that should take available space. It uses `flex: 1 1 16rem`; `--bl-inline-grow-basis` adjusts the preferred width. Other children retain their natural sizing. The growing child can wrap to its own row, and reading order stays unchanged. This annotation has no effect outside a direct inline child.

Container sizes `sm`, `md`, `lg` and `xl` cap the inner wrapper at 40rem, 60rem, 80rem and 96rem. `full` removes the cap. The wrapper is centered and its maximum width includes inline gutters. Containers do not add vertical padding. Use a stack for vertical rhythm. Nesting containers adds their gutters; use `gutter="0"` when a parent already supplies the inset.

## Content, nesting and CSS

Each component has one default slot and exposes its internal box as `::part(layout)`. The slot participates in the layout with `display: contents`; the custom-element host remains a normal block box and a layout item when nested. The elements supplied directly to stack, inline and grid have zero block margins (enforced with `!important`) so document typography cannot silently add to the gap. Use gap or a content wrapper when additional block spacing is needed. Descendant margins and all container content margins are preserved. Assigned elements get `min-inline-size: 0`; the application owns text wrapping and the sizing of media or other intrinsically wide content. Wrap text nodes in elements when they need explicit sizing or styling.

The components preserve `hidden` on hosts and children. They do not generate semantic sections, headings, lists or forms. Put semantic markup in the content, such as an `<article>` inside a grid or a layout inside a labelled `<section>`. A layout element is not a replacement for `<ul>`/`<li>` or table structure. Form-associated controls retain their normal light-DOM form ownership when nested inside layouts.

| CSS custom property                              | Use                                                     |
| ------------------------------------------------ | ------------------------------------------------------- |
| `--bl-layout-gap`                                | Override shared gap on stack, inline or grid            |
| `--bl-layout-row-gap` / `--bl-layout-column-gap` | Override inline/grid axis gaps                          |
| `--bl-inline-grow-basis`                         | Preferred width of a direct child marked `data-bl-grow` |
| `--bl-grid-min-item-width`                       | Override the preferred automatic grid minimum           |
| `--bl-container-max-width`                       | Override the container cap                              |
| `--bl-container-gutter`                          | Override the inline gutter                              |

Overrides inherit into nested layouts. Set them on a subtree only when shared settings are intended, or use `::part(layout)` for an individual box. Properties define default inline styles; CSS rules on `::part(layout)` can override those styles. Use rem for content-facing lengths. Inline defaults to wrapping; `wrap="nowrap"` can overflow if children cannot shrink. No observers, listeners or global styles are installed.

## CMS integration

Layout settings can be stored alongside content as a versioned tree:

```json
{
  "version": 1,
  "root": {
    "kind": "container",
    "size": "md",
    "gutter": 4,
    "children": [
      {
        "kind": "stack",
        "gap": 6,
        "children": [
          { "kind": "heading", "text": "Review records" },
          { "kind": "text", "text": "Keep source material in reading order." }
        ]
      }
    ]
  }
}
```

The demo's `pages/layouts/schema.ts` validates version 1, known block kinds and settings, up to 100 blocks, eight nesting levels, 24 children per layout and 2,000 characters per text field. `render-document.ts` maps those blocks to explicit Lit templates and renders content as text. Invalid input retains the last valid preview. This is a bounded integration example owned by the demo, not a package document format or a full CMS editor. Applications own schema versioning, migrations, rich-content policies, storage, authorization, drag handles and selection controls. Validate persisted data before assigning component properties; component fallbacks are a rendering convenience, not a document validator.

## Composition patterns

The `/layouts` demo includes working patterns with copyable markup:

- **Section header:** a native `<section>` and `<header>`, with an inline baseline-aligned heading and related link. Row and column gaps are independent when it wraps.
- **Filter bar:** a native named search form with a growing labelled input and naturally sized actions.
- **Content cards:** native `<article>` elements in a container-responsive grid, using nested stacks to keep headings and descriptions close.

Use the semantic HTML appropriate to the content, and use layout primitives inside those boundaries. A stack can sit inside a form; an article can be a grid child. Keep lists and tables valid by retaining their native parent/child structure. These are composition examples, not additional custom elements.

The demo's CMS preset selector stores section-header and content-card compositions as version-1 trees. Inline/grid nodes can specify `rowGap` and `columnGap`; inline supports `align: "baseline"`; grids support the responsive column presets. Any node may set `grow: true` to opt in when it is a direct inline child. The decoder validates these additions while continuing to accept earlier version-1 trees. CMS presets describe composition; the native section and form boundaries in the demo remain application-owned.

## Demo adoption

The shared shell uses inline/stack for its header, preferences and footer, and a container for routed content. Library galleries, reference examples, tool demonstrations, operations metrics, navigation links and motion samples compose the primitives with their existing native semantic elements. Standalone font, glyph and editor pages explicitly register the layout entry for their control and comparison groups.

Surface styling remains in demo CSS. Per-box adjustments such as the catalogue's fine shared borders use `::part(layout)` so they do not change nested gaps. The same applies to the routed page's width cap: applying an inherited container override there would also override every nested container. Unequal image/text frames, native list/definition/table structure, positioned decorations, specimen drawings and animation geometry retain focused CSS where it expresses that responsibility more directly.
