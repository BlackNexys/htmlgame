# Reusable multi-value relationships

`bl-combobox multiple` extends the existing searchable single-value control with an ordered selection and built-in removable chips. It reuses its query, popup placement, remote-result ownership and keyboard behavior. The default single-selection API and the existing `selection` slot remain unchanged. `bl-chip` remains a filter toggle.

```html
<bl-combobox multiple name="category" label="Categories" required></bl-combobox>
```

```ts
import { listen } from '@blacklight/signal-soul/events';

const picker = document.querySelector('bl-combobox')!;
picker.options = [
  { value: 'history', label: 'History' },
  { value: 'culture', label: 'Culture' },
];
picker.values = ['legacy'];
picker.selectedLabels = { legacy: 'Former category' };
const stop = listen(picker, 'bl-change', (event) => {
  if ('values' in event.detail) console.log(event.detail.values);
});
// Call stop() when the owning view is removed.
```

Set initial values before connecting the element when they should be the form-reset defaults. See the working example at `/library/bl-combobox`.

## Contract

Set the property-only `values: readonly string[]` for multiple mode. Identities are nonempty string values; duplicates and invalid entries are removed in first-occurrence order. `value` remains the independent single-selection property and is ignored by multiple-mode submission. Switching modes preserves both selections. Programmatic changes emit no user events.

The component submits one FormData entry per selected value under `name`, in selection order. Query text is never submitted. Empty multiple selection submits no entries. Required validity depends on the selection count. Disabled controls and disabled ancestor fieldsets omit all entries and disable search, removal and clear actions. Reset restores the initial selections. Multiple state restoration accepts the component's versioned JSON state; malformed or unsupported state is ignored. Restore data is bounded to 1000 identities and 100000 serialized characters. Restoration never emits selection intent.

Selecting an option adds it once, clears the query, retains input focus and keeps the popup open for another selection. Already selected options are omitted from the results. Disabled options cannot be added, but an existing selected value remains until explicitly removed, even if its option becomes disabled or disappears. The application owns record permissions and invalidation policy.

Supply `selectedLabels: Readonly<Record<string,string>>` for selected records absent from the current options. Labels resolve from current options, supplied selected labels, remembered selection labels, then identity. The component remembers selected labels across result paging. Duplicate option labels include visible identity metadata in their accessible names. Selected duplicates also show identity metadata in their chips; remove-button names always include the identity.

User changes emit `bl-change` with an immutable `{values, addedValues, removedValues}` snapshot, then a composed native `change` event. The component applies changes itself, consistent with single-selection form controls. Single mode keeps `{value,label}`. Search intent remains `bl-query-change: {query}`; selecting a multiple option emits the empty-query intent so an application adapter can refresh suggestions. Remote fetching, cancellation and stale-response handling remain application responsibilities.

## Keyboard and focus

Search retains the existing arrows, Enter, Escape, Tab and IME handling. Tab visits each chip's native remove button and the input. Backspace in an empty search field focuses the final remove button without deleting immediately; Enter/Space activates removal, and Delete/Backspace also removes a focused chip. Focus then moves to the next remaining chip or the search field. Clear all returns focus to search. Removing a focused chip programmatically returns focus to search; keyed rendering preserves focus through label changes. No custom left/right token-navigation model is imposed on text editing.

Chip states use the established rectangular field and flat outlined token styling, with visible focus and comfortable button targets. Loading/error feedback does not hide or discard existing selections. Messages use `blacklight.combobox.selected`, `remove`, `clearMultiple` and `count` in addition to the existing combobox keys.

## Scope and verification

The library owns selection, labels, repeated form entries, validity, reset and interaction. The catalogue demonstrates local choices and application-owned result paging. The prior application-owned chip composition remains as a compatibility example. No CMS schema, fetching, hidden-input convention or backend is embedded in the control. Use bounded result sets (a few hundred visible options) and application paging for larger datasets; this control does not virtualize results.

Verification on 3 November 2026:

- 24 multiple-mode checks passed across desktop and mobile Chromium profiles using installed Edge, including order/deduplication, remote labels, duplicate identities, required/disabled forms, reset/restoration, mode switching, IME, chip focus/removal, modal popups, translated messages, reconnection and disappearing remote results.
- 20 existing single-combobox and application-owned relationship-composition checks passed across both profiles. A further 24 form-regression, localization and copyable-usage checks passed.
- Library and demo builds, TypeScript, ESLint, glyph/source guards and package dry-run passed. The package includes the new declarations, implementation helpers and this guide. Repository formatting still reports the pre-existing `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs` issues.
- Dark desktop and light mobile examples were visually inspected. Automated layout checks cover 320px RTL, 24px root text, forced colors, reduced motion, long escaped labels and removal targets of at least 44px.

Manual NVDA/Firefox and VoiceOver/Safari review remains pending; Chromium mobile emulation does not cover physical devices or certify accessibility.
