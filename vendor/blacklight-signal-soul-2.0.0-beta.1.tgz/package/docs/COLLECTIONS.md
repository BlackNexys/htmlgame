# Collection selection and bulk actions

## Table contract

`bl-data-table` keeps its existing `selectable`, `selected` and `bl-row-select` radio-selection contract. Set `selectable` and `selection-mode="multiple"` to opt into native checkboxes. `selectedKeys` and `disabledKeys` are property-only arrays of string keys. Multiple selection is controlled: consume `bl-selection-change` and assign the accepted `detail.selectedKeys` back to the component. The event bubbles and is composed, with `{selectedKeys, addedKeys, removedKeys, scope: 'row' | 'page'}`. It does not emit the single-selection event or modify `selected`.

Multiple-selection identities come from `rowKey` (default `id`) and must be unique nonempty strings or finite numbers, compared as strings. Missing, empty or duplicate keys disable their row checkboxes; indices are not stable identities. The existing single-selection index fallback remains for compatibility. `disabledKeys` disables matching rows in either mode. A disabled selected row remains selected until the application changes its selected state.

The header checkbox selects/deselects eligible rows on the displayed page, excludes disabled/invalid rows, and reflects all/some/none through checked and indeterminate native state. Off-page keys retain their order and membership in proposed changes. Newly selected keys append in displayed order. Loading and error states block multiple-selection intent. Empty/no-eligible pages disable the header checkbox.

Sorting, filtering, paging and row replacement never implicitly clear `selectedKeys`. Applications decide when removed records, changed permissions or a different dataset invalidate selection. Selecting all matching records is a separate application action with an explicit count and scope; the table does not select unloaded records. Native table semantics and its keyboard-focusable horizontal scroll region remain unchanged.

`sortKey` (`sort-key`) and `sortDirection` (`sort-direction`, `asc`/`desc`) expose the existing sort state. Header activation still updates that state and emits the existing `bl-sort-change` payload. Programmatic updates emit no intent. With `external-sort`, the application supplies rows in the requested order; binding the sort properties keeps the header's `aria-sort` state aligned when a saved view or toolbar changes sorting.

## Application composition

The `/collections` demo owns records, filtering, sorting, pagination, saved views, cross-page selection and simulated archive operations. Saved views contain only filter/sort state and remain in memory with the cached page until reload. The page header checkbox never implies all matching records. An explicit action selects every eligible matching fixture record and states the exact count; changing the filter does not hide how many selected records lie outside that filter or page.

Bulk actions snapshot explicit record keys before confirmation. The toolbar states scope, pending work, successes, skipped/ineligible rows and partial failures. Successful archives leave selection; failed records remain selected for an explicit retry. The simulated adapter owns permission checks and deterministic failure/retry behavior. Local abort does not prove a remote write was rolled back; route cleanup cancels the local operation and reports cancellation without claiming server success.

Small screens retain every table column through the labelled scroll region and explain horizontal scrolling. Status, scope and recovery actions remain outside the scroll container. Application-level confirmation, lifecycle cleanup and async helpers are composed rather than embedded in the table.

Filters and pagination remain usable during an archive; they do not change the confirmed snapshot. Internal application links can confirm leaving pending work. Browser history and direct programmatic navigation bypass that demo link guard; disconnection still cancels the local task and the cached page retains selection. This is not a browser unload or server transaction guard.

## Verification boundaries

Verify controlled intent/rollback, native mixed state, disabled/invalid identities, stable keys across sorting/paging/removal, keyboard operation, loading/error states and single-selection compatibility. Exercise cross-page scope, saved views, filters, bulk partial failures/retry and teardown. Review narrow layouts, both themes, RTL, forced colors and larger text. Manual NVDA/Firefox and VoiceOver/Safari review remains separate from browser automation.

Verified on 29 October 2026 using installed Edge with Playwright desktop and mobile-emulation profiles: 86 checks passed across table selection, collection workflows, component refinement/usage, media workflows, regressions, cached-page architecture and navigation. After tightening saved-view validation, all 14 collection checks passed, including repeated rejection of malformed or unsupported views. Type checking, ESLint, library/demo builds, source guards and package dry-run passed. Desktop dark and narrow RTL light layouts were visually reviewed. The full formatting check reports existing issues in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`; changed files pass formatting. Manual assistive-technology review remains pending.
