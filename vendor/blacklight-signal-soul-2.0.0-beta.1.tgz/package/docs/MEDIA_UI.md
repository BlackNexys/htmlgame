# File input and media workflows

## Contract and ownership

The media milestone introduces `bl-file-input`, an atom using the shared form-control base and a native file input. `files` is a read-only snapshot of user-selected files. The component owns browse/drop interaction, accept/count/size feedback, clearing and form association. Applications own uploads, persistence, previews, metadata, server validation and authorization.

Public inputs are `name`, `accept`, `multiple`, `maxFiles` (`max-files`, zero means unlimited), `maxFileSize` (`max-file-size`, bytes, zero means unlimited), `required`, `disabled`, `label`, `help`, `error`, and `messages`. Constraints apply identically to browsing and dropping. A batch is accepted in full or rejected in full; rejection preserves the previous selection and invalidates the control until cleared, replaced, or made valid by changed constraints. `accept` supports extensions, exact MIME types and MIME wildcards; an unavailable MIME type does not establish a match unless an extension rule matches.

Accepted user selections and clearing a nonempty selection emit `bl-change` with `{files}` followed by native `change`. Rejections emit `bl-file-reject` with `{files, issues}`, where issues have `code: 'accept' | 'size' | 'count'`, plus the relevant `file` or `limit`. All events bubble and are composed. Property changes, reset and restoration do not emit user-change events. The read-only `validationIssues` exposes current constraint feedback, rechecking retained files when constraints change. `clear()` is a user-style action and respects disabled state.

FormData contains one entry per selected file under `name`, preserving selection order and original names. Empty and disabled controls contribute no entries. The inherited string `value` is unused. Reset clears the selection. Restoration clears it and announces reattachment when the saved state indicates files existed; it never reconstructs files from serialized content. The component stores only a restoration marker as form state.

Browsing remains the primary action and uses native keyboard behavior. The drop area offers the same validation. Shared field labels delegate focus, and help, validation feedback and filenames are described within the input's shadow root. Filenames render as text. Client-side constraints provide feedback; servers validate independently.

## Catalogue workflow

The file-input catalogue composes an upload queue with queued, uploading, complete, failed and cancelled states, and a media-picker dialog. Local deterministic upload simulation supports progress, failure, retry and cancellation. A completed result remains completed when cancellation comes too late; a local abort does not imply a remote operation was undone.

The application owns each preview URL and revokes it on removal, replacement and route teardown. Files and temporary URLs are excluded from JSON drafts. Existing-asset selection and usage metadata are application state: alternative text describes the intended use, and decorative intent is explicit. Crop editing is outside this milestone.

## Verification boundaries

Browser checks cover browse/drop parity, events, FormData, reset/restoration, disabled fieldsets, constraint updates, upload cancellation/retry, URL cleanup and metadata selection. Review both themes, forced colors, RTL and narrow layouts. NVDA/Firefox and VoiceOver/Safari remain manual review requirements; browser automation alone does not establish assistive-technology compatibility.

### Implementation verification, 29 October 2026

Library/demo builds, TypeScript checking, source guards and the package dry run passed. The broader Edge run passed 72 checks across desktop and mobile-emulation profiles, covering media, selection, existing forms, localization, catalogue usage and UI services. After final constraint and layout adjustments, all 14 file-input/media-workflow checks passed again.

Visual inspection covered light/dark themes and a narrow RTL media dialog. Browser checks also exercised file-input feedback at 320px with larger root fonts and forced colors. These are bounded Edge checks, not physical-device or cross-browser evidence. NVDA/Firefox and VoiceOver/Safari review has not been performed.

The full ESLint pass succeeded. Repository-wide formatting remains blocked by existing differences in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`; changed media files pass formatting.
