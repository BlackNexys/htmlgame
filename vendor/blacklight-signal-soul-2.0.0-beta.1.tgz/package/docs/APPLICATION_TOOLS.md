# Application tools

These optional modules help build applications around the components. They add no dependencies. The headless entries work without Lit; the `/lit` entries contain Lit reactive controllers. Importing them does not start routing, attach document listeners, register custom elements, or change the theme. Create an instance per application or scope and tear it down with its owner.

| Entry              | Exports                                           | Responsibility                      |
| ------------------ | ------------------------------------------------- | ----------------------------------- |
| `/router`          | `createMatcher`, `createRouter`                   | URL matching and browser navigation |
| `/router/lit`      | `RouterController`                                | Lit outlet loading and cancellation |
| `/events`          | `emit`, `listen`, `createEvents`                  | Typed DOM events                    |
| `/lifecycle`       | `DisposableScope`                                 | Listeners, timers and subscriptions |
| `/lifecycle/lit`   | `LifecycleController`                             | Reconnectable host effects          |
| `/application`     | Context, forms, async tasks, preferences, actions | Application state and workflows     |
| `/application/lit` | `ContextController`, `LifecycleController`        | Optional host integration           |

Use these as `@blacklight/signal-soul/router`, etc. The main component entry stays independent. These tools use browser standards such as `AbortController`, `structuredClone`, and `URL`; no polyfills are included.

## Routes and outlets

```ts
import { createRouter } from '@blacklight/signal-soul/router';

const router = createRouter({
  mode: 'hash',
  routes: [
    { name: 'records', path: '/records' },
    { name: 'record', path: '/records/:id' },
    { name: 'files', path: '/files/*rest' },
  ],
});
const unsubscribe = router.subscribe((match) => {
  console.log(match?.name, match?.params.id, match?.query.get('tab'));
});
const stop = router.start();
router.navigate({ name: 'record', params: { id: 'BL-102' }, query: { tab: 'history' } });
// #/records/BL-102?tab=history
stop(); // Stop browser listeners; start() can reconnect.
unsubscribe();
router.dispose(); // Final teardown.
```

`createMatcher(routes)` provides pure `match(path)` and `path(location)` without a window. At the first differing segment, static routes precede parameters, and parameters precede wildcards; exact routes precede their wildcard fallback. `:id` captures one decoded segment; `*rest` captures the remaining segments and must be last. Names and normalized paths must be unique. Parameters are encoded when building URLs. Missing required parameters and dot segments (`.` or `..`, which URLs would normalize) throw; unmatched or malformed encoded paths return `undefined`. Match snapshots expose `route`, `name`, `path`, `params`, `query`, `hash`, and `href`. Route names are inferred; required parameter names are checked at runtime.

Hash mode accepts both `#records` and `#/records`; generated links use `#/records`. History mode uses `mode: 'history'` and optional `basePath: '/app'`. Configure the server to serve the app for deep URLs in history mode. `router.href(location)` builds a link without navigating. `navigate(location, { replace: true })` replaces the current history entry. String destinations must be local absolute paths such as `/records`; external origins are rejected. Call `start()` once per owner. Subscribers receive the initial route at startup and subsequent URL changes, including unmatched routes. Subscribing by itself does not call the listener. `navigate()` also works before startup and publishes immediately.

The router does not intercept links, enforce access control, fetch data, or decide titles, focus, scroll, or unsaved-change prompts. The application owns those policies. Route configuration and returned `URLSearchParams` should be treated as immutable.

For a Lit host, use an outlet ref:

```ts
import { createRef, ref } from 'lit/directives/ref.js';
import { RouterController } from '@blacklight/signal-soul/router/lit';

// Instance fields inside a LitElement; router is explicitly supplied by the app.
readonly outlet = createRef<HTMLElement>();
readonly routes = new RouterController(this, router, {
  outlet: () => this.outlet.value,
  load: async (match, signal) => {
    const element = document.createElement('record-page');
    // Populate the page; pass signal to any asynchronous application work.
    return element;
  },
  notFound: () => document.createTextNode('Page not found'),
  onError: () => document.createTextNode('Could not open this page'),
});
// In render(): html`<main ${ref(this.outlet)}></main>`
```

The controller aborts previous loads on navigation or host disconnection, ignores stale results, and exposes `pending` and `error`. Returned nodes are mounted directly; HTML strings are not accepted. `afterRender(node, match, signal)` can implement application focus and scroll behavior. Keep delayed effects cancellation-aware. A disconnected host unsubscribes and reconnects to the current route.

Caching is opt-in with `cacheKey: match => match.path`. Include query parameters in the key when they affect page identity. `clearCache()` drops retained entries; it does not dispose application resources or remove the current page. Cached custom elements must clean up effects on disconnection. Without a key, each navigation loads a new node.

## Typed events

```ts
import { listen, createEvents } from '@blacklight/signal-soul/events';

const stop = listen(checkbox, 'bl-change', (event) => {
  console.log(event.detail.checked); // Inferred for a typed BlCheckbox reference.
});
const events = createEvents<{ 'record-save': { id: string } }>();
events.listen(container, 'record-save', (event) => saveRecord(event.detail.id));
events.emit(button, 'record-save', { id: 'BL-102' });
stop();
```

`listen` infers native event types and existing Blacklight event details. Component-specific `bl-change` details are narrowed when the target has its component type. `createEvents` defines application-owned contracts without a global event bus or global type augmentation. Its emit/listen functions still use ordinary DOM dispatch and propagation. Both listener helpers return cleanup functions and accept native listener options, including `signal`.

`emit(target, type, detail, options)` emits existing library event contracts. Events bubble and cross shadow boundaries by default, preserving component behavior. They are not cancelable unless `{ cancelable: true }` is supplied; dispatch returns `false` when a cancelable event is prevented. Existing native `addEventListener` and Lit `@event` bindings remain supported.

## Lifecycle cleanup

```ts
import { DisposableScope } from '@blacklight/signal-soul/lifecycle';
const scope = new DisposableScope();
window.addEventListener('resize', resize, { signal: scope.signal });
scope.add(store.subscribe(render));
scope.timeout(refresh, 1000);
// When the owner ends:
scope.dispose();
```

Disposal aborts the scope and runs cleanups once, in reverse registration order. Manual cleanup returned by `add`, `timeout`, or `interval` is also idempotent. Adding cleanup to an already disposed scope runs it immediately. All cleanups run even when one throws; errors are reported together as `AggregateError`.

Inside a Lit host, `new LifecycleController(this, scope => { ... })` runs setup after rendering, when refs exist. Each connection receives a fresh scope. A returned cleanup is added to that scope; disconnection disposes it. Setup is synchronous; launch asynchronous work explicitly with the supplied signal. Continue using Lit's own `ref` directive for direct element binding.

## Scoped context

```ts
import { createContext, provideContext, getContext } from '@blacklight/signal-soul/application';
const sessionContext = createContext<{ user: string }>('session');
const provider = provideContext(appRoot, sessionContext, { user: 'Vivian' });
const session = getContext(descendant, sessionContext);
provider.update({ user: 'Navarro' });
provider.dispose();
```

Each token has a unique identity, even if descriptions match. Consumers resolve the nearest provider through composed DOM events, including shadow boundaries and slots. An optional second argument to `createContext` supplies a default. An explicitly provided `undefined` stays `undefined`. Duplicate providers for the same token on one root throw. A provider is scoped to an element or shadow root; it is not a singleton dependency container or a security boundary.

`subscribeContext(element, token, callback)` calls back initially and on provider updates, replacement, and disposal. Its returned cleanup ends the subscription. Plain DOM consumers must reconnect the subscription when reparented. Lit consumers can use `new ContextController(this, token)` and render its `.value`; the controller manages disconnection and reparenting. Context values are references: call `provider.update(nextValue)` to notify consumers rather than mutating silently. The existing translation service keeps its own public context API; components still receive finished labels from the application.

## Async state

```ts
import { createAsyncTask } from '@blacklight/signal-soul/application';
const records = createAsyncTask(async (query: string, signal) => {
  const response = await fetch(`/records?q=${encodeURIComponent(query)}`, { signal });
  if (!response.ok) throw new Error('Could not load records');
  return response.json();
});
const stop = records.subscribe((state) => render(state));
await records.run('Vivian');
records.cancel();
stop();
records.dispose();
```

`.state.status` is `idle`, `pending`, `success`, or `error`, with `value` or `error` as applicable. Pending retains the last value. Subscribers receive subsequent state changes; read `.state` for the initial snapshot. Each run aborts the previous one. Stale successes and failures cannot replace the current state even when the operation ignores its signal.

`run` resolves with `{ status: 'success', value }`, `{ status: 'error', error }`, or `{ status: 'cancelled' }`. Operation failures are represented as state and outcomes; starting a disposed task throws. Cancellation resets state to idle, but an operation that ignores its signal can keep running, and its returned promise waits for that operation to settle. Cancellation cannot undo external writes. Retry is another `run` with explicit input. State snapshots are shallowly frozen; returned values belong to the application.

## Form workflows

```ts
import { createFormController } from '@blacklight/signal-soul/application';
const workflow = createFormController({
  read: () => ({ name: nameInput.value }),
  apply: (value) => {
    nameInput.value = value.name;
  },
  validate: (value) => ({ name: value.name.trim() ? '' : 'Enter a name.' }),
  onErrors: (errors) => {
    field.error = errors.name ?? '';
  },
});
nameInput.addEventListener('input', () => workflow.change('name'));
form.addEventListener('submit', async (event) => {
  event.preventDefault();
  const outcome = await workflow.submit((value, signal) => save(value, signal), form);
  // Handle success, error, cancelled, invalid, or busy.
});
```

`read` and `apply` keep field bindings application-owned. Models must support `structuredClone`. `change(field?)` reads current values and optionally clears that field's custom error. `.value` is a copy; `.errors` and `.summary` expose custom messages (`{ field, message }`). Bind the summary and focus targets in the app. `validate(form?)` combines custom messages with native `reportValidity()`; native invalid events remain available, but native messages are not automatically copied into the custom summary.

`.dirty` compares current state with the initial or last successful submission baseline. The default equality uses JSON serialization; supply `equals` for models requiring different semantics. `setValue` applies values without changing the baseline. `reset(value?)` cancels a submission, applies values, clears errors and establishes a new baseline. A successful submission establishes the submitted snapshot as baseline, preserving dirty state for edits made during the request. Duplicate submissions return `busy`. `.pending`, `.state`, and `subscribe` support button loading and feedback. Application-defined labels and server error mappings stay in the app; use `setErrors` for returned field messages. `.cancel()` aborts pending work; `.dispose()` ends the controller's lifetime.

Optional `draft: { key, storage: () => sessionStorage, decode }` enables `saveDraft()`, `restoreDraft()`, and `clearDraft()`. Data is serialized as JSON, and `decode(unknown)` must validate it before use. Restoration returns a boolean and retains the baseline. Invalid JSON, rejected data, and blocked storage are tolerated. Persistence is explicit; drafts are not silently saved or cleared on submission. Store only data appropriate for the chosen browser storage.

## Preferences

```ts
import { createPreferences } from '@blacklight/signal-soul/application';
type Theme = 'system' | 'light' | 'dark';
const preferences = createPreferences<{ theme: Theme }>({
  defaults: { theme: 'system' },
  validate: {
    theme: (value): value is Theme => ['system', 'light', 'dark'].includes(String(value)),
  },
  prefix: 'my-app-',
  storage: () => localStorage,
});
const stop = preferences.connect(window); // Opt-in cross-tab synchronization.
preferences.set('theme', 'dark');
stop();
```

Preferences support strings, finite numbers, booleans, and null. Provide runtime validators for restricted values. Stored values are validated on load, invalid values fall back to defaults, and invalid `set` calls throw. Without validators, values must match the default's primitive type. Storage is optional; unavailable storage leaves an in-memory instance. Subscribers receive changes, `.values` returns a shallow frozen snapshot, and `reset()` restores defaults and removes stored keys. Defaults and validators are configuration and should not be mutated after creation.

JSON storage is the default, including for strings. `storageFormat: 'raw'` supports pre-existing unquoted string preferences; use the same format when reading and writing. `connect(window)` listens to matching storage keys and returns a cleanup; it does not set document attributes or apply a theme. The application decides how values affect the UI. Storage events for another storage area are ignored.

## Shared actions

```ts
import { createAction } from '@blacklight/signal-soul/application';
const saveAction = createAction({
  id: 'save-record',
  label: () => translations.t('record.save'),
  icon: 'save',
  enabled: () => workflow.dirty,
  execute: (_input: void, signal) => save(workflow.value, signal),
});
// Bind the same action to a button or menu:
// .disabled=${!saveAction.enabled} @click=${() => saveAction.run(undefined)}
// Render saveAction.label and subscribe for async state changes.
```

Actions share identity, optional icon, dynamic label/enabled state, execution, and async status. Disabled or already-pending actions return `{ status: 'disabled' }`; otherwise they use the async task outcomes above. `cancel` and `dispose` end work; a disposed action stays disabled. Label and enabled functions are evaluated when read. Subscribe to external dependencies separately when they change. Actions install no shortcuts or menu system; the application binds them to accessible controls and owns confirmation and authorization.

## Demo and verification

The demo uses the public router for URL state, lifecycle scopes for cached pages, preferences for theme/motion, form workflows for Intake, and an action for the primary example. Page caching, section anchors, focus, titles, translations and fictional sample data remain demo-owned. The optional Lit outlet adapter is exercised in a dedicated development fixture.

Run `pnpm typecheck`, `pnpm lint:eslint`, `pnpm build`, `pnpm build:demo`, and the browser suite. `tests/application-*.spec.ts` covers matching/history, stale outlet loads, cleanup, scoped context, task cancellation, preferences, validation, drafts and actions on desktop/mobile profiles. `tests/application-contracts.ts` also checks event and route typing during typecheck. These checks do not replace application-specific routing, storage, accessibility, or authorization tests.
