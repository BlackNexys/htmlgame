# Revision comparison and restore

The `/revisions` demo composes existing fields, selects, tables, buttons and confirmation services. It introduces no public library component or server protocol. It uses the structured editor's `EditorRecord`, validation, form controller and version-checked persistence adapter. Each demo page owns its own simulated store; `/editor` and `/revisions` are not a shared backend.

## History and comparison

History records stable version numbers, authorship, timestamps and cloned structured snapshots. Reading history or the latest record returns copies. A successful save or restore appends a version; restoring never deletes history or moves the version counter backward. Remote-change simulation also appends a version. The editor's existing default store still begins at version 1; the revision example supplies three fictional seed versions.

Comparisons use labelled structured fields and stable related-link IDs, including link order. Before/After and Added/Removed/Changed/Unchanged text accompany semantic del/ins markup. All content is escaped Lit text, including URLs and HTML-looking strings. No diff HTML is accepted or injected, and no rich-text comparison is attempted.

## Restore and conflict decisions

Restore preview compares the chosen source with the current local draft. Confirmation identifies the source and expected current version and warns about unsaved edits. Controls lock while restoring. The adapter checks the expected version after simulated latency; a stale request cannot overwrite newer work. Failure or cancellation preserves both the current draft and history. A successful restore creates a new version containing the source content and provenance, then resets the form baseline to that saved snapshot.

Saving uses the existing form controller, so edits made during a save remain dirty after its submitted snapshot succeeds. Conflicts preserve the local draft and show the remote version. A three-way reconciliation compares the accepted baseline, local draft and remote snapshot. Changes made on only one side are retained automatically. Fields changed differently on both sides require explicit Local/Remote choices. Related links (including order) and the optional note (including its enabled flag) are cohesive groups. Applying a resolution prepares an unsaved draft against the displayed remote version; saving is a separate action and rechecks the version. Loading remote content instead requires confirmation before discarding local edits. A remote update during reconciliation requires another review.

## Lifecycle and verification

Internal application links ask before leaving dirty or pending work. Browser history bypasses the link guard; cached values remain, while disconnection cancels local operations and invalidates outstanding confirmations. No browser-unload, durable storage or remote rollback guarantee is provided. Reload resets the fixtures. Manual simulation can fail the next write or append a remote version, including while a write is pending.

A shared-shell confirmation already open during browser-history navigation may remain until dismissed; answering that old confirmation cannot start a write after reconnection.

Verify escaped field comparison, immutable snapshots, append-only restoration, failed/cancelled restore, stale version rejection, edits during save, three-way choices, repeated remote changes, stale confirmations and reconnection. Review keyboard focus, narrow RTL layouts, both themes, large text and forced colors. Manual NVDA/Firefox, VoiceOver/Safari and physical-device review remain pending.

Verified on 3 November 2026 using installed Edge and Playwright desktop/mobile-emulation profiles: all 30 revision model/workflow checks passed, together with 44 existing structured-editor, navigation and cached-page lifecycle checks. Library/demo builds, type checking, ESLint, source guards and package dry-run passed. Dark desktop and narrow light layouts were visually reviewed; automated coverage includes narrow RTL, larger text and forced colors. Changed files pass formatting; the full formatting check still reports pre-existing issues in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`. Manual assistive-technology review remains pending.
