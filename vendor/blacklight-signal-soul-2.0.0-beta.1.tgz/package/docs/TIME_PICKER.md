# Time and combined date/time pickers

`bl-time-picker` is a form-associated custom 24-hour clock field. Its hour/minute editor is also used inside `bl-date-picker type="datetime-local"`. Both follow the existing rectangular field, flat panel, Signal heading and indigo action styling. They do not invoke the browser's native time or date/time picker UI.

## Time contract

`value`, `min` and `max` use `HH:mm`. No date, timezone or seconds are implied. `minuteStep` (`minute-step`) accepts positive divisors of 60 up to 30, default 1; invalid increments fall back to 1. Minutes align to zero within the hour. Reversed time bounds describe an overnight interval, such as 22:00–02:00. Malformed bounds are ignored. Typed invalid text stays visible and is omitted from FormData; valid out-of-range or off-step values submit but invalidate the control. An optional empty value submits an empty string.

The popup stages edits until Apply time. Cancel, Escape and backdrop dismissal preserve the original value. Hour and minute number fields support typing and native ArrowUp/ArrowDown keys. Explicit plus/minus buttons wrap each segment independently, without carrying into another hour or date. Applying or clearing emits composed input then change, once if the value changed. Typing in the main field emits input and then the normal change on commit. Programmatic values do not emit events.

`inline` renders the shared editor directly. Inline edits emit input immediately and change on segment commit or an increment action. Incomplete segments remain editable and invalid. It is used inside the combined date/time picker without a separate form name, so the outer control submits one value. Inline segment input/change events are stopped by the outer picker until Apply.

The control supports `name`, `label`, `help`, `error`, `required`, `disabled`, `readOnly` (`readonly`), `messages`, `show()`, `hide()` and readonly `open`. Reset restores the initial value; restoration accepts strings. Disabling/readonly state, switching to inline mode, reset, restoration and disconnection close the popup. Focus returns to the opener on Apply/Cancel. UI messages use `blacklight.timePicker.*`; date-independent values always use 24-hour ISO order.

## Combined contract

`bl-date-picker` defaults to `type="date"`. Set `type="datetime-local"` for the combined calendar and inline clock. `value`, `min` and `max` then use `YYYY-MM-DDTHH:mm`; the main field displays a space between date and time and accepts either space or T while typing. Calendar bounds use the date portions; the chosen boundary day also constrains the time. Complete local date/time bounds are compared together. Reversed combined bounds permit no selection. `today` remains a date-only override.

The calendar and clock stage a single local value. Selecting a day focuses the clock and keeps the dialog open; Apply date and time commits the complete value once. A missing/invalid time or out-of-range combination disables Apply. Today changes the draft date and preserves the draft time. Clear commits an empty value. Cancel restores the committed value. Programmatic value changes while open replace the draft; changing type closes the dialog. Date-only mode retains its existing immediate day selection behavior.

The scheduling demo defaults to the combined custom control; its separate mode uses the same custom date and time controls. The application still resolves timezones and daylight-saving ambiguity and confirms an exact instant. The controls never infer an instant from a wall time.

The demo retains the exact combined text during incomplete edits and splits only at the first date/time separator. Replacing a complete value therefore preserves the first typed character, and malformed trailing text cannot be silently discarded before validation.

## Verification

Exercise 00:00/23:59, typing and increment controls, partial input, step and range errors, overnight bounds, reset/restore, readonly and inherited disabled behavior, Apply/Cancel, event isolation, focus containment, combined boundary days, and scheduling timezone resolution. Review both themes, narrow RTL layouts, large text and forced colors. Manual screen-reader and physical-device review remains separate from browser automation.

Verified on 29 October 2026 using installed Edge and Playwright desktop/mobile-emulation profiles: 104 regression checks passed across combined/time/date pickers, native date/time inputs, scheduling, forms, catalogue discovery and usage. After preserving raw scheduling input and refining inline error descriptions, all 38 focused combined/time/scheduling checks passed. Library/demo builds, type checking, ESLint, source guards (56 registered elements) and package dry-run passed. Combined desktop dark/mobile light and standalone time-picker layouts were visually reviewed; narrow RTL, larger text and forced colors are exercised automatically. Changed files pass formatting. The full formatting check retains pre-existing issues in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`. Manual assistive-technology and physical-device review remains pending.
