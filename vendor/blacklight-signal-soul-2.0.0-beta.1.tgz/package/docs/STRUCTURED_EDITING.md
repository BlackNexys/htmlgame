# Structured editing composition

The `/editor` demo combines existing controls, layout primitives and application tools. It introduces no public CMS-specific component. `demo/pages/editor/` owns the model, validation targets, persistence simulation, autosave policy, draft storage feedback and views in focused modules.

## Form and focus contract

Related links have stable IDs and keyed rendering. Add/remove/move actions update model order without using array positions as identity. Move controls work with a keyboard; focus stays with the moved entry and a live message announces its new position. Removing an entry focuses a remaining entry or the add action.

English and Danish are content locales, independent of the interface language. Both translations stay in the model and are validated and saved together. Language tabs show error counts. Error-summary links activate the appropriate language or expand the links disclosure before delegating focus to the custom control's native input.

The native form uses `novalidate` so application validation can include inactive language panels and collapsed sections before focusing anything. One schema validates all required titles, link labels, HTTP/HTTPS URLs and the optional note. Its nested targets adapt to the form controller's existing top-level error keys; the application owns the detailed summary and target registry. Server field errors are applied only when the same stable target still exists and its current value matches the submitted value.

Turning off the review note retains its content in the model and draft and persists it as inactive content. The hidden control is disabled and the note is excluded from required validation. Applications can choose a different conditional-field policy; hiding does not imply deletion.

## Saving and conflicts

The existing `createFormController` owns the baseline, dirty tracking, validation and pending submission. The persistence adapter waits deterministically, supports save failure and field rejection, and checks the submitted server version. It represents a simulated backend inside the cached page; reload does not preserve simulated server saves.

The save indicator distinguishes unsaved, saving, saved, failed and conflicting state. Successful saves advance the submitted snapshot's baseline, leaving edits made during the request dirty. Failure preserves the current model. Conflicts require an explicit decision to load the latest simulated version; dirty local values are replaced only after confirmation.

Autosave is opt-in, uses a 700ms debounce, and schedules another save after success if newer edits remain. It pauses on validation errors, failure or conflict instead of retrying indefinitely. Background validation does not move focus. Route teardown cancels the debounce and pending local request. A real persistence adapter must reconcile server outcomes because aborting a local request cannot undo a completed write.

## Drafts and leaving

Draft saving, restoration and discarding are explicit actions. The versioned JSON decoder accepts only the known shape, bounded strings, valid stable IDs and a bounded link list. Unfinished field values may be restored. An unsupported or oversized current record cannot overwrite a previously stored draft. No files or temporary media URLs enter this draft model. Restoring replaces local values after confirmation and retains the saved-version baseline. Discarding storage does not clear editor values. Storage failures and invalid stored drafts are visible.

The demo router asks the active page's `beforeLeave()` hook before following an internal application link to another page. The editor uses the confirmation service for dirty or pending work. Same-page links keep their current behavior. This application hook does not change the public headless router API.

Browser back/forward navigation and programmatic history changes do not run the link hook; the cached editor retains its values and cancels active work on disconnection. Full reloads and external navigation use a best-effort `beforeunload` prompt when dirty or pending. Browser policy and mobile lifecycle events can suppress that prompt. Draft recovery is available only for explicitly stored data and is not guaranteed after every interruption.

## Verification

Exercise repeaters with keyboard-only input; error links into inactive/collapsed content; conditional values; save failure and server errors; editing during a save; autosave; version conflicts; draft restore/discard and blocked storage; and leaving/reconnecting while dirty or pending. Review both themes, narrow containers, RTL, forced colors and larger text. Manual NVDA/Firefox and VoiceOver/Safari review remains separate from browser automation.

### Implementation verification, 29 October 2026

The final Edge run passed 94 checks across desktop and mobile-emulation profiles. It included all 24 structured-editor checks, application routing/form workflows, cached-page reconnection, navigation, existing page flows and all 54 component references in both themes. Editor checks covered 320px RTL layout with larger root text and forced colors. Visual inspection also covered dark desktop and light RTL phone layouts. These checks do not replace physical devices or assistive technology; NVDA/Firefox and VoiceOver/Safari review has not been performed.

Library/demo builds, TypeScript checking, source guards, package dry run, ESLint and changed-file formatting passed. Repository-wide formatting still reports the existing differences in `src/molecules/disclosure.ts` and `vscode-theme/scripts/release-check.mjs`.
